<!-- BEGIN VENDOR JS-->
<script src="../../assets/js/vendors.min.js"></script>
<!-- BEGIN VENDOR JS-->
<!-- BEGIN PAGE VENDOR JS-->
<!-- END PAGE VENDOR JS-->
<!-- BEGIN THEME  JS-->
<script src="../../assets/js/plugins.min.js"></script>
<script src="../../assets/js/search.min.js"></script>
<script src="../../assets/js/custom/custom-script.min.js"></script>
<!-- END THEME  JS-->
<!-- BEGIN PAGE LEVEL JS-->
<!-- END PAGE LEVEL JS-->
</body>
</html>